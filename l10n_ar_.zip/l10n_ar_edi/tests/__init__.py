# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import common
from . import test_fe
from . import test_fex
from . import test_bfe
from . import test_monotributista
