# Part of Odoo. See LICENSE file for full copyright and licensing details.
from . import l10n_ar_afip_ws_consult
